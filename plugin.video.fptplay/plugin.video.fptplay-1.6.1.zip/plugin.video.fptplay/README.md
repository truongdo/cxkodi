fpt.data is from local directory

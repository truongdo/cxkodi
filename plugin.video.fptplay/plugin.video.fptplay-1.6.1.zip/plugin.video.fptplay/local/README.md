python get_data.py > fpt.data
